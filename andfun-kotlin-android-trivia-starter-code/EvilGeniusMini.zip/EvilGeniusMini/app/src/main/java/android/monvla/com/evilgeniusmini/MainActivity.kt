package android.monvla.com.evilgeniusmini

import androidx.appcompat.app.AppCompatActivity

class MainActivity {
}